import styled from "styled-components";

export const GatheringlistWrapper = styled.div`
  display: flex;
  margin: 10px 100px;
  background-color: beige;
  padding:50px;
  align-items: left;
  border-radius: 30px;`;



