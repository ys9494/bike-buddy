import { RentalLocationWrapper } from "./rental-location-styled";

const RentalLocation = () => {
  return (
    <RentalLocationWrapper>
      <div>대여소 정보 페이지</div>
    </RentalLocationWrapper>
  );
};

export default RentalLocation;
