import styled from "styled-components";

export const GetheringlistWrapper = styled.div``;