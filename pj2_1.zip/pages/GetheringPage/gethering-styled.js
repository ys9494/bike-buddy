import styled from "styled-components";

// const GetheringWrapper = styled.div`
//   background-color: teal;
//   width: 100px;
//   height: 100px;
// `;

// const Title= styled.div`
//   display: flex;
//   color:darkolivegreen;

//   h1{
//     font-size: 30px;
//     margin: 0 10px 10px 0;
//   }
// `;

// const Box = styled.div`
//   background-color: teal;
//   width: 100px;
//   height: 100px;
// `;

// function GetheringWrapper() {
//   return (
//     <div>
//       <Title>
//         <Box />
//       </Title>
//     </div>
//   );
// }

export const GetheringWrapper= styled.div`
  display: flex;
  flex-direction: column;
  position: relative;
  top:50px;
  width: flex;
  background-color: beige;
  padding:20px;
  align-items: center;

`;