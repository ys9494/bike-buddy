import styled from "styled-components";

export const UsergetheringWrapper = styled.div``;