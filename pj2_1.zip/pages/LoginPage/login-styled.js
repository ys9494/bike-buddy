import styled from "styled-components";

export const LoginWrapper = styled.div``;

export const InputWrapper = styled.div``;

export const LoginForm = styled.form``;

export const LoginButton = styled.div``;
