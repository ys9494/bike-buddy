import { SignupWrapper } from "./signup-styled";

const Signup = () => {
  return (
    <SignupWrapper>
      <div>signup page</div>
    </SignupWrapper>
  );
};

export default Signup;
